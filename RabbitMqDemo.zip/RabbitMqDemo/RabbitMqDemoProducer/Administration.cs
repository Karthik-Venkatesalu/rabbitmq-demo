﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;

namespace RabbitMqDemoProducer
{
	public static class Administration
	{
		private const String DeadLetterQueueMask = "{0}.DeadLetter";
		private const Boolean DurableQueue = true;

		public static void CreateQueueWithDeadLetterQueue(IModel channel, String queueName, Int32 retryTimeInSeconds)
		{
			if (channel == null)
				throw new ArgumentNullException("channel");

			if (String.IsNullOrEmpty(queueName))
				throw new ArgumentNullException("queueName");

			String deadLetterQueueName = String.Format(DeadLetterQueueMask, queueName);

			channel.ExchangeDeclare(queueName, "direct");

			channel.QueueDeclare(
				queue: queueName,
				durable: DurableQueue,
				exclusive: false,
				autoDelete: false,
				arguments: GetQueueParameters(
					queueName: queueName,
					deadLetterQueue: deadLetterQueueName));

			channel.QueueBind(
				queue: queueName,
				exchange: queueName,
				routingKey: queueName);

			channel.QueueDeclare(
			queue: deadLetterQueueName,
			durable: DurableQueue,
			exclusive: false,
			autoDelete: false,
			arguments: GetDeadLetterQueueParameters(
				queueName: queueName,
				retryTimeInSeconds: retryTimeInSeconds));

			channel.QueueBind(
				queue: deadLetterQueueName,
				exchange: queueName,
				routingKey: deadLetterQueueName);
		}

		private static Dictionary<String, Object> GetQueueParameters(String queueName, String deadLetterQueue)
		{
			return
				new Dictionary<String, Object>()
				{
					{ "x-dead-letter-exchange", queueName },
					{ "x-dead-letter-routing-key", deadLetterQueue }
				};
		}

		private static Dictionary<String, Object> GetDeadLetterQueueParameters(String queueName, Int32 retryTimeInSeconds)
		{
			return
				new Dictionary<String, Object>()
				{
					{ "x-dead-letter-exchange", queueName },
					{ "x-dead-letter-routing-key", queueName },
					{ "x-message-ttl", retryTimeInSeconds * 1000 }
				};
		}
	}
}
