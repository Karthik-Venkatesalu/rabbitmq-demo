﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;

namespace RabbitMqDemoProducer
{
	internal class RabbitMQProducer
	{
		public void SendMessage(Byte[] body, String queueName)
		{
			var factory = new ConnectionFactory()
			{
				HostName = ConfigurationManager.AppSettings["RabbitMQServerAddress"].ToString(),
				Port = Convert.ToInt32(ConfigurationManager.AppSettings["RabbitMQPort"])
			};

			using (var connection = factory.CreateConnection())
			{
				using (var channel = connection.CreateModel())
				{
					Administration.CreateQueueWithDeadLetterQueue(
						channel: channel,
						queueName: queueName,
						retryTimeInSeconds: Convert.ToInt32(ConfigurationManager.AppSettings["RabbitMQRetryTimeInSeconds"]));

					channel.BasicPublish(
												exchange: queueName,
												routingKey: queueName,
												basicProperties: null,
												body: body);

					connection.Close();
				}
			}
		}
	}
}
