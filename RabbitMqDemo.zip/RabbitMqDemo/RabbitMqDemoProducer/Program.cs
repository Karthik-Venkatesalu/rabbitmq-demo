﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMqDemoProducer
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Start sending your messages :)");
			string message = Console.ReadLine();

			while (!string.IsNullOrEmpty(message))
			{
				byte[] body = Encoding.UTF8.GetBytes(message);

				RabbitMQProducer producer = new RabbitMQProducer();
				producer.SendMessage(body, ConfigurationManager.AppSettings["RabbitMQClientWebToConnectQueue"].ToString());

				message = Console.ReadLine();
			}
		}
	}
}
