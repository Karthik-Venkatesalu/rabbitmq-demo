﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RabbitMqDemo
{
	internal class Program
	{
		static void Main(string[] args)
		{
			Consumer consumer = new Consumer();

			Task task = Task.Factory.StartNew(() =>
		   {

			   consumer.Start(ConfigurationManager.AppSettings["RabbitMQClientWebToConnectQueue"].ToString());
		   });

			//task.Wait(5 * 1000);

			//consumer.Dispose();

			Console.ReadLine();
		}
	}
}
