﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;

namespace RabbitMqDemo
{
	internal class Consumer : IDisposable
	{
		private IConnection _connection;
		private IModel _channel;

		public void Start(string queueName)
		{
			var connectionFactory = new ConnectionFactory()
			{
				HostName = ConfigurationManager.AppSettings["RabbitMQServerAddress"].ToString(),
				Port = Convert.ToInt32(ConfigurationManager.AppSettings["RabbitMQPort"])
			};

			_connection = connectionFactory.CreateConnection();
			_channel = _connection.CreateModel();

			Administration.CreateQueueWithDeadLetterQueue(_channel, queueName, Convert.ToInt32(ConfigurationManager.AppSettings["RabbitMQRetryTimeInSeconds"]));

			var consumer = new EventingBasicConsumer(_channel);

			consumer.Received += Consumer_Received;

			_channel.BasicConsume(
				queue: queueName,
				noAck: false,
				consumer: consumer);
		}

		private void Consumer_Received(object sender, BasicDeliverEventArgs e)
		{
			_channel.BasicAck(e.DeliveryTag, false);
			Console.WriteLine(Encoding.UTF8.GetString(e.Body));
		}

		public void Dispose()
		{
			if (_connection != null)
			{
				_connection.Dispose();
				_connection = null;
			}

			if (_channel != null)
			{
				_channel.Dispose();
				_channel = null;
			}
		}
	}
}
